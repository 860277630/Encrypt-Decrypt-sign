package com.example.demo;

import org.junit.Test;

import java.security.NoSuchAlgorithmException;
import java.util.Map;

public class EncryptDecryptTest {

    //AES加密测试
    @Test
    public void testAES(){
        String str = "zhangsan";
        String key = "this is a key";
        System.out.println("===加密前字符串为：==="+str+"===密钥为：==="+key);
        byte[] ciphertext = AESUtils.encrypt(str,key);
        String ciphertextStr = ParseUtils.parseByte2HexStr(ciphertext);
        System.out.println("===加密后密文为：==="+ciphertextStr);
        System.out.println("*********************************************");
        System.out.println("===开始解密，密钥为：==="+key);
        byte[] ciphertextByte = ParseUtils.parseHexStr2Byte(ciphertextStr);
        byte[] text  = AESUtils.decrypt(ciphertextByte,key);
        System.out.println("===解密后为：==="+new String(text));
    }

    //DES加密测试
    @Test
    public void testDES() throws Exception {
        //待加密内容
        String str = "测试内容";
        //密钥，长度要是8的倍数
        String key = "9588028820109132";
        System.out.println("===加密前字符串为：==="+str+"===密钥为：==="+key);
        byte[] result = DESUtils.encrypt(str.getBytes(),key);
        String resultStr = ParseUtils.parseByte2HexStr(result);
        System.out.println("===加密后密文为：==="+resultStr);
        System.out.println("*********************************************");
        System.out.println("===开始解密，密钥为：==="+key);
        byte[] resultByte = ParseUtils.parseHexStr2Byte(resultStr);
        byte[] decryResult = DESUtils.decrypt(resultByte, key);
        System.out.println("===解密后为：==="+new String(decryResult));

    }


    //MD5加密测试
    @Test
    public void testMD5(){
        String str = "测试内容";
        System.out.println("加密内容为："+str);
        System.out.println("加密后内容为："+MD5Utils.encrypt(str));
    }

    //RSA  对称加密
    @Test
    public void testRSA() throws Exception {		//生成公钥和私钥
        Map<Integer, String> keyMap = RSAUtils.genKeyPair();
        //加密字符串
        String message = "df723820";
        System.out.println("随机生成的公钥为:" + keyMap.get(0));
        System.out.println("随机生成的私钥为:" + keyMap.get(1));
        String messageEn = RSAUtils.encrypt(message,keyMap.get(0));
        System.out.println(message + "\t加密后的字符串为:" + messageEn);
        String messageDe = RSAUtils.decrypt(messageEn,keyMap.get(1));
        System.out.println("还原后的字符串为:" + messageDe);
    }

    //进行sign签名
    @Test
    public void testSIgn(){
        String timeStamp = "1552008562";
        String nonce = "MLE7Wq";
        String secretId = "cxfca3";
        String sign = SignUtils.createSignature("1552008562", "MLE7Wq", secretId);
        System.out.println("timeStamp:"+timeStamp);
        System.out.println("nonce:"+nonce);
        System.out.println("secretId:"+secretId);
        System.out.println("signature:" + sign);
    }
}
