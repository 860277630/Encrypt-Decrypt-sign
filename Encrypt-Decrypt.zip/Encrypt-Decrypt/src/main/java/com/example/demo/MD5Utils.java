package com.example.demo;


import org.springframework.util.DigestUtils;

//md5加密  因为是不可逆的  所以不存在解密的方法
public class MD5Utils {
    public static String encrypt(String content){
        return DigestUtils.md5DigestAsHex(content.getBytes());
    }
}
